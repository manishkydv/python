import random  # Importing the random module for selecting random responses and agents.

# User name input
name = input("Enter your name: ").capitalize()  # Prompt user for their name and capitalize the first letter.
print(f"Welcome {name} to Chatbot! You can ask anything about our university. Type 'help' for topics or 'bye' to exit.")  # Welcome message.

# Dictionary for chatbot responses
responses = {
    'name': ['The name of the university is The University of Poppleton.'],  
    'hello': ['Hello, How can I help you?', 'Welcome, How may I help you?'],  
    'principal': ['The name of our Principal is Dr. Lomas.'],  
    'admission': [
        'Admissions start from january 1st. Visit www.universityofpoppleton.com for more details.'
    ],  # Admission-related information.
    'location': ['Our university is located in York, UK.'],  
    'facilities': [
        'We offer a variety of facilities, including sports, a cafe, a library, a VR room, a swimming pool, state-of-the-art labs, and more.'
    ],  # Facilities available.
    'history': [
        'The University of Poppleton was founded in 1967 and has been a leader in academic excellence ever since.'
    ],  # University history.
    'courses': [
        'We offer undergraduate and postgraduate programs in Computer Science, Engineering, Arts, Business, and more. For the full list, visit our website.'
    ],  # Information about courses offered.
    'contact': [
        'You can contact us at info@universityofpoppleton.com or call us at +44 123 456 7890.'
    ],  # Contact details.
    'help': [
        "You can ask about the following: university name, principal, admission dates, location, facilities, history, courses, or contact details."
    ],  # Help menu.
    'noreply': [
        "I'm sorry, I didn't understand that.",
        "Could you please rephrase your question?"
    ]  # Default response for unrecognized queries.
}

# Randomly assign an agent
agents = ['Chandan', 'sadhan', 'Mansu', 'kp oli', 'Harry', 'joheb']  
user_agent = random.choice(agents)  
print(f"Hello, I am your agent {user_agent}.")  

# Create or open a chat log file
log_file_name = f"{name}_chat_log.txt"  
with open(log_file_name, "w") as log_file:
    log_file.write(f"Chat Session with Agent {user_agent}\n")
    log_file.write(f"User: {name}\n")
    log_file.write("--------------------------------------------------\n")

    # Chatbot loop
    while True:
        choice = input("Ask Chatbot: ").lower()  
        log_file.write(f"User: {choice}\n")  

        if choice == 'bye':  # If user types 'bye', exit the loop.
            feedback_option = input("Would you like to provide feedback? (yes/no): ").lower()
            log_file.write(f"User Feedback Option: {feedback_option}\n")  

            if feedback_option == 'yes':  
                feedback = input("Please provide your feedback: ")  
                log_file.write(f"User Feedback: {feedback}\n")  
                print("Thank you for your feedback!")  
            else:
                print("No problem! Thank you for chatting with us.")  

            farewell = "Bye! It was nice talking with you."  
            print(farewell)
            log_file.write(f"Agent: {farewell}\n")  
            break  

        found = False  # Flag to track if a matching response is found.
        for key in responses.keys():  
            if key in choice:  
                reply = random.choice(responses[key])  
                print(reply)  # Display the response to the user.
                log_file.write(f"Agent: {reply}\n")  
                found = True  
                break  

        if not found:  # If no matching key is found.
            noreply = random.choice(responses['noreply'])  # Select a default "no reply" response.
            print(noreply)  # Display the "no reply" response.
            log_file.write(f"Agent: {noreply}\n")  # Log the "no reply" response.

print(f"Chat session logged in '{log_file_name}'.") 
